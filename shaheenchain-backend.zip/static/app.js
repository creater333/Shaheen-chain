async function api(path, method = "GET", body) {
  const r = await fetch(path, {
    method,
    headers: { "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
  return r.json();
}
const $ = (id) => document.getElementById(id);
let COIN = { name: "Gold Coin", symbol: "GLD" };

async function refresh() {
  const me = await api("/api/me");
  if (!me.user) {
    $("authView").classList.remove("hidden");
    $("dashView").classList.add("hidden");
    $("adminView").classList.add("hidden");
    return;
  }
  $("authView").classList.add("hidden");
  $("dashView").classList.remove("hidden");
  $("who").textContent = "Hi, " + me.user.username;
  $("logoutBtn").classList.remove("hidden");
  if (me.user.is_admin) $("adminBtn").classList.remove("hidden");
  const d = await api("/api/dashboard");
  if (d.ok) {
    COIN = { name: d.coin_name, symbol: d.coin_symbol };
    $("stPoints").textContent = d.points;
    $("stCoinLabel").textContent = `${d.coin_name} (${d.coin_symbol})`;
    $("stCoin").textContent = d.coin_balance;
    $("stComm").textContent = d.commission_earned;
    $("stRefs").textContent = d.referrals;
    $("myCode").textContent = d.referral_code;
    $("appName").textContent = d.settings.app_name;
    $("walletInfo").textContent =
      `Balance: ${d.points} points = ${d.coin_balance} ${d.coin_symbol} (${d.points_per_coin} points = 1 ${d.coin_symbol}, min conversion ${d.min_convert_points} points)`;
    // Withdrawal section: hidden + "coming soon" while the kill-switch is OFF.
    $("wdComingSoon").classList.toggle("hidden", d.withdrawals_enabled);
    $("wdForm").classList.toggle("hidden", !d.withdrawals_enabled);
  }
  loadTasks(); loadWithdrawals(); loadMining(); loadBonus(); loadConversions(); loadAds();
}

async function login() {
  const r = await api("/api/login", "POST", { username: $("username").value, password: $("password").value });
  $("authMsg").textContent = r.ok ? "" : r.error;
  if (r.ok) refresh();
}
async function register() {
  const r = await api("/api/register", "POST", { username: $("username").value, password: $("password").value, referral_code: $("refCode").value });
  $("authMsg").textContent = r.ok ? "Account created!" : r.error;
  if (r.ok) refresh();
}
async function logout() { await api("/api/logout", "POST"); location.reload(); }

function showTab(name, btn) {
  ["mining", "tasks", "wallet", "refs"].forEach((t) =>
    $("tab-" + t).classList.toggle("hidden", t !== name));
  if (btn) {
    document.querySelectorAll(".tabs button").forEach((b) =>
      b.classList.toggle("active", b === btn));
  }
  if (name === "refs") loadRefs();
}
function showDash() { $("adminView").classList.add("hidden"); $("dashView").classList.remove("hidden"); }

async function loadMining() {
  const s = await api("/api/mining/status");
  $("mineStatus").textContent = s.active
    ? `⛏ Mining running: ${s.elapsed_hours}h elapsed, ~${s.accrued_coins} points ready (${s.rate}/hour, max ${s.max_hours}h)`
    : "No active mining session.";
  $("mineClaimInfo").textContent =
    `Claim interval: ${s.min_claim_interval_min} min between claims.` +
    (s.claim_wait_minutes > 0 ? ` Next claim in ~${s.claim_wait_minutes} min.` : "");
}
async function mineStart() {
  const r = await api("/api/mining/start", "POST");
  $("mineMsg").textContent = r.ok ? "Mining started!" : r.error; loadMining();
}
async function mineClaim() {
  const r = await api("/api/mining/claim", "POST");
  $("mineMsg").textContent = r.ok ? `Claimed ${r.claimed} points!` : r.error; loadMining(); refresh();
}

async function loadTasks() {
  const t = await api("/api/tasks");
  $("taskList").innerHTML = (t.tasks || []).map((x) => `
    <div class="item"><b>${x.title}</b> — ${x.reward} points (cooldown ${x.cooldown_hours}h)<br>
    <small>${x.description}</small><br>
    ${x.available
      ? `<button onclick="completeTask(${x.id})">Complete</button>`
      : `<span>⏳ Available in ~${x.cooldown_remaining_minutes} min</span>`}</div>`).join("");
}
async function completeTask(id) {
  const r = await api("/api/tasks/complete", "POST", { task_id: id });
  $("taskMsg").textContent = r.ok ? `+${r.reward} points!` : r.error;
  if (r.ok && r.show_interstitial && r.interstitial) showInter(r.interstitial);
  loadTasks(); refresh();
}

async function loadBonus() {
  const b = await api("/api/bonus/status");
  if (!b.ok) return;
  $("bonusStatus").textContent = b.can_claim
    ? `Ready! Claim ${b.points} bonus points.`
    : `Next bonus in ~${b.cooldown_remaining_hours}h (${b.points} points, cooldown ${b.cooldown_hours}h).`;
  $("bonusBtn").disabled = !b.can_claim;
}
async function claimBonus() {
  const r = await api("/api/bonus/claim", "POST");
  $("bonusMsg").textContent = r.ok ? `+${r.points} bonus points!` : r.error;
  loadBonus(); refresh();
}

async function convertPoints() {
  const r = await api("/api/convert", "POST", { points: parseInt($("convPoints").value || "0", 10) });
  $("convMsg").textContent = r.ok ? `Converted! +${r.coins_received} ${r.coin_symbol}` : r.error;
  loadConversions(); refresh();
}
async function loadConversions() {
  const c = await api("/api/conversions");
  $("convList").innerHTML = (c.conversions || []).map((x) => `
    <div class="item">${x.points_spent} points → ${x.coins_received} ${COIN.symbol}
    <small> (${new Date(x.created_at).toLocaleString()})</small></div>`).join("") || "No conversions yet.";
}

async function withdraw() {
  const r = await api("/api/withdraw", "POST", {
    method: $("wdMethod").value, account: $("wdAccount").value,
    amount_points: parseInt($("wdAmount").value || "0", 10),
  });
  $("wdMsg").textContent = r.ok ? `Request sent! ${r.coins_used} points held.` : r.error;
  loadWithdrawals(); refresh();
}
async function loadWithdrawals() {
  const w = await api("/api/withdrawals");
  $("wdList").innerHTML = (w.withdrawals || []).map((x) => `
    <div class="item">${x.method} — ${x.amount_points} points held — <b>${x.status}</b>
    ${x.admin_note ? `<br><small>Note: ${x.admin_note}</small>` : ""}</div>`).join("") || "No requests yet.";
}
async function loadRefs() {
  const r = await api("/api/referrals");
  $("refList").innerHTML =
    "<h3>Your referrals</h3>" +
    ((r.referrals || []).map((x) => `<div class="item">${x.username} — ${x.points} points</div>`).join("") || "None yet.") +
    "<h3>Commissions earned</h3>" +
    ((r.commissions || []).map((x) => `<div class="item">Level ${x.level} from ${x.from_user}: +${x.coins} points (${x.source})</div>`).join("") || "None yet.");
}

// ---- ads ----
function adCard(p, size) {
  if (p.provider === "Custom" && p.snippet) {
    return `<div class="ad-card ${size}"><span class="ad-tag">Sponsored · Custom</span>${p.snippet}</div>`;
  }
  if (p.provider === "Custom" && p.image_url) {
    return `<div class="ad-card ${size}"><span class="ad-tag">Sponsored · Custom</span>` +
      `<a href="${p.click_url || "#"}" target="_blank" rel="noopener"><img src="${p.image_url}" alt="Sponsored"></a></div>`;
  }
  return `<div class="ad-card ${size}"><span class="ad-tag">Sponsored</span>` +
    `<b>${p.provider} Ad</b><br><small>${p.placement_type} · unit: ${p.unit_id || "(not set)"}</small>` +
    `<br><small class="hint">Demo placeholder — real ad loads in the mobile app</small></div>`;
}
async function loadAds() {
  const a = await api("/api/ads");
  if (!a.ok) return;
  const banners = (a.providers || []).filter((p) => p.placement_type === "banner");
  $("bannerSlot").innerHTML = banners.map((p) => adCard(p, "banner")).join("");
  const rewarded = (a.providers || []).filter((p) => p.placement_type === "rewarded");
  $("rewardedSlot").innerHTML = rewarded.length
    ? rewarded.map((p) => `
      <div class="ad-card rewarded"><span class="ad-tag">Sponsored</span>
      <b>${p.provider} Rewarded Ad</b> — watch to earn ${a.rewarded_bonus_points} points<br>
      <button onclick="watchRewarded(${p.id})">▶ Watch Ad</button></div>`).join("")
    : "<p class='hint'>No rewarded ad provider is enabled right now.</p>";
}
async function watchRewarded(id) {
  const r = await api("/api/ads/rewarded", "POST", { provider_id: id });
  $("adMsg").textContent = r.ok ? `+${r.points} points for watching the ad!` : r.error;
  if (r.ok) refresh();
}
function showInter(p) {
  $("interAdContent").innerHTML = adCard(p, "interstitial");
  $("interModal").classList.remove("hidden");
}
function closeInter() { $("interModal").classList.add("hidden"); }

// ---- admin ----
async function showAdmin() {
  $("dashView").classList.add("hidden");
  $("adminView").classList.remove("hidden");
  const s = await api("/api/admin/stats");
  if (s.ok) {
    $("aUsers").textContent = s.total_users;
    $("aPoints").textContent = s.points_in_circulation;
    $("aCoins").textContent = s.coins_in_circulation;
    $("aPend").textContent = s.pending_withdrawals;
    $("aAppr").textContent = s.approved_withdrawals;
  }
  loadAdminUsers(); loadAdminTasks(); loadAdminWd(); loadSettings(); loadAdminAds();
}
async function loadAdminUsers() {
  const q = $("userSearch").value;
  const r = await api("/api/admin/users?q=" + encodeURIComponent(q));
  $("adminUserList").innerHTML = (r.users || []).map((u) => `
    <div class="item"><b>${u.username}</b> ${u.is_admin ? "(admin)" : ""} — ${u.points} points, ${u.coin_balance} coins ${u.is_banned ? "⛔ BANNED" : ""}
    <br><button onclick="banUser(${u.id}, ${u.is_banned ? 0 : 1})">${u.is_banned ? "Unban" : "Ban"}</button>
    <button onclick="adjustUser(${u.id})">Adjust balance</button></div>`).join("");
}
async function banUser(id, ban) {
  await api("/api/admin/users/ban", "POST", { user_id: id, ban: !!ban });
  loadAdminUsers();
}
async function adjustUser(id) {
  const delta = parseInt(prompt("Points to add (use negative to deduct):") || "0", 10);
  if (!delta) return;
  const reason = prompt("Reason:") || "";
  const r = await api("/api/admin/users/adjust", "POST", { user_id: id, delta, reason });
  if (!r.ok) alert(r.error);
  loadAdminUsers();
}
async function loadAdminTasks() {
  const r = await api("/api/admin/tasks");
  $("adminTaskList").innerHTML = (r.tasks || []).map((t) => `
    <div class="item"><b>${t.title}</b> — ${t.reward} points, cooldown ${t.cooldown_hours}h ${t.enabled ? "" : "(disabled)"}
    <button onclick="editTask(${t.id}, '${t.title.replace(/'/g, "")}', ${t.reward}, ${t.cooldown_hours})">Edit</button>
    <button class="danger" onclick="delTask(${t.id})">Delete</button></div>`).join("");
}
async function addTask() {
  await api("/api/admin/tasks", "POST", { title: $("ntTitle").value, description: $("ntDesc").value,
    reward: parseInt($("ntReward").value || "0", 10),
    cooldown_hours: parseFloat($("ntCooldown").value || "24") });
  loadAdminTasks();
}
async function editTask(id, title, reward, cooldown) {
  const t2 = prompt("Title:", title); if (t2 === null) return;
  const r2 = parseInt(prompt("Reward points:", reward) || "0", 10);
  const c2 = parseFloat(prompt("Cooldown hours:", cooldown) || "24");
  await api("/api/admin/tasks", "POST", { id, title: t2, reward: r2, cooldown_hours: c2 });
  loadAdminTasks();
}
async function delTask(id) {
  await api("/api/admin/tasks/delete", "POST", { id });
  loadAdminTasks();
}
async function loadAdminWd() {
  const r = await api("/api/admin/withdrawals");
  $("adminWdList").innerHTML = (r.withdrawals || []).map((w) => `
    <div class="item"><b>${w.username}</b> — ${w.method} ${w.account} — ${w.amount_points} points — <b>${w.status}</b>
    ${w.status === "pending" ? `<br><button onclick="decideWd(${w.id}, 'approve')">Approve</button>
    <button class="danger" onclick="decideWd(${w.id}, 'reject')">Reject</button>` : ""}
    ${w.admin_note ? `<br><small>Note: ${w.admin_note}</small>` : ""}</div>`).join("") || "None.";
}
async function decideWd(id, action) {
  const note = prompt("Admin note (optional):") || "";
  await api("/api/admin/withdrawals/decide", "POST", { id, action, note });
  loadAdminWd(); showAdmin();
}
async function loadAdminAds() {
  const r = await api("/api/admin/ads");
  if (!r.ok) return;
  $("adBonus").value = r.rewarded_bonus_points;
  $("adFreq").value = r.interstitial_every_n_tasks;
  $("adminAdList").innerHTML = (r.providers || []).map((p) => `
    <div class="item" data-pid="${p.id}">
      <b>${p.provider}</b><br>
      <label>Enabled <select class="ad-enabled"><option value="1" ${p.enabled ? "selected" : ""}>On</option><option value="0" ${p.enabled ? "" : "selected"}>Off</option></select></label>
      <label>Placement <select class="ad-placement">
        <option ${p.placement_type === "banner" ? "selected" : ""}>banner</option>
        <option ${p.placement_type === "interstitial" ? "selected" : ""}>interstitial</option>
        <option ${p.placement_type === "rewarded" ? "selected" : ""}>rewarded</option>
        <option ${p.placement_type === "custom" ? "selected" : ""}>custom</option></select></label>
      <label>Ad unit / placement ID <input class="ad-unit" value="${p.unit_id || ""}"></label>
      <label>Custom snippet (HTML/JS, Custom only) <input class="ad-snippet" value="${(p.snippet || "").replace(/"/g, "&quot;")}"></label>
      <label>Custom image URL <input class="ad-img" value="${p.image_url || ""}"></label>
      <label>Custom click link <input class="ad-click" value="${p.click_url || ""}"></label>
    </div>`).join("");
}
async function saveAds() {
  const providers = [...document.querySelectorAll("#adminAdList .item")].map((el) => ({
    id: parseInt(el.dataset.pid, 10),
    enabled: el.querySelector(".ad-enabled").value === "1",
    placement_type: el.querySelector(".ad-placement").value,
    unit_id: el.querySelector(".ad-unit").value,
    snippet: el.querySelector(".ad-snippet").value,
    image_url: el.querySelector(".ad-img").value,
    click_url: el.querySelector(".ad-click").value,
  }));
  const r = await api("/api/admin/ads", "POST", { providers,
    rewarded_bonus_points: $("adBonus").value, interstitial_every_n_tasks: $("adFreq").value });
  $("adSetMsg").textContent = r.ok ? "Ads saved!" : (r.error || "failed");
}
async function loadSettings() {
  const r = await api("/api/admin/settings");
  if (!r.ok) return;
  const s = r.settings;
  $("sAppName").value = s.app_name; $("sMining").value = s.mining_enabled;
  $("sRate").value = s.coins_per_hour; $("sMaxH").value = s.max_mining_hours;
  $("sClaimInt").value = s.min_claim_interval_min;
  $("sL1").value = s.l1_pct; $("sL2").value = s.l2_pct; $("sL3").value = s.l3_pct;
  $("sWd").value = s.withdrawals_enabled; $("sMinWd").value = s.min_withdrawal_points;
  $("sCoinName").value = s.coin_name; $("sCoinSym").value = s.coin_symbol;
  $("sPpc").value = s.points_per_coin; $("sMinConv").value = s.min_convert_points;
  $("sBonusPts").value = s.daily_bonus_points; $("sBonusCd").value = s.daily_bonus_cooldown_hours;
}
async function saveSettings() {
  const r = await api("/api/admin/settings", "POST", {
    app_name: $("sAppName").value, mining_enabled: $("sMining").value,
    coins_per_hour: $("sRate").value, max_mining_hours: $("sMaxH").value,
    min_claim_interval_min: $("sClaimInt").value,
    l1_pct: $("sL1").value, l2_pct: $("sL2").value, l3_pct: $("sL3").value,
    withdrawals_enabled: $("sWd").value, min_withdrawal_points: $("sMinWd").value,
    coin_name: $("sCoinName").value, coin_symbol: $("sCoinSym").value,
    points_per_coin: $("sPpc").value, min_convert_points: $("sMinConv").value,
    daily_bonus_points: $("sBonusPts").value, daily_bonus_cooldown_hours: $("sBonusCd").value,
  });
  $("setMsg").textContent = r.ok ? "Saved!" : (r.error || "failed");
}
async function changePass() {
  const r = await api("/api/admin/change-password", "POST", { new_password: $("newPass").value });
  $("passMsg").textContent = r.ok ? "Password changed!" : r.error;
}

refresh();
